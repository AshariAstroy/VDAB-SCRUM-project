Scrum Verkoop

This is a sales management system made with ASP.NET Core MVC.
It has three layers: Data, Service, and Web.

==============================
How to run the project
==============================

1. Local development:
   - Open the solution: ScrumVerkoop.sln
   - Set ScrumVerkoopWeb as the startup project in Visual Studio
   - Run the project (Ctrl + F5), the browser will open the home page

2. Online (server):
   - Open in your browser:
     http://dotnetscrum.tenobe.org/verkoop

==============================
Project structure
==============================

Solution "Scrum Verkoop"

ScrumVerkoopData
  - Dependencies
  - Models            (Database entities from EF Core)
  - Repositories
      - AdresRepository
      - BestelingRepository
      - IAdresRepository
      - IBestelingRepository
      - IKlantRepository
      - IPersoneelslidRepository
      - ISecuritygroepRepository
      - KlantRepository
      - PersoneelslidRepository
      - PrulariaComContext (DbContext)

ScrumVerkoopService
  - Dependencies
  - AccountService
  - AdresService
  - BestellingService
  - KlantService

ScrumVerkoopWeb
  - Dependencies
  - Properties
  - wwwroot
  - Controllers
      - AccountController
      - BestelingController
      - HomeController
      - KlantController
  - Models (ViewModels)
      - AdresViewModel
      - BestellingArtikelLine
      - BestellingDetailsViewModel
      - BestellingenListViewModel
      - BestellingListLine
      - ContactPersoonViewModel
      - ErrorViewModel
      - KlantDetailViewModel
      - KlantenListViewModel
      - KlantListDetailViewModel
      - LoginViewModel
      - PersonenViewModel
      - RegistreerPersoneelViewModel
  - Security
      - SecuritygroepMembershipHandler
      - SecurityManager
      - SecurityMembershipRequirement
  - Views
      - Account
            - AccessDenied
            - Account
            - Login
            - Registreer
      - Bestelling
            - _BestellingAdressen
            - _BestellingArtikels
            - _BestellingKlant
            - _BestellingSummary
            - Annuleer
            - Detail
            - Edit
            - Index
            - UpdateAdres
      - Home
            - Index
            - Privacy
      - Klant
            - BevestigAccountStatus
            - Detail
            - Index
            - UpdateAdres
      - Shared
            - _ViewImports
            - _ViewStart
  - appsettings
  - Program


==============================
Features
==============================

- Customer management (Klant): view customer information and their orders, edit details, change status (Active/Non-active), edit addresses
- Address management (Adres): edit customer addresses from the Klant page, edit order addresses when allowed
- Order management (Bestelling): view orders, edit order addresses when allowed, cancel orders when allowed
- Account / Login: login required to access the website, users can change password
- Web UI: pages for users to see and interact with data, includes Klant, Bestelling, Account, and Home pages
- Security: access controlled by roles and security groups

==============================
Technology
==============================

- .NET (version: .NET 9)
- ASP.NET Core MVC
- Entity Framework Core
- SQL Server

==============================
Tests
==============================

Currently, no unit tests are added.

==============================
Team Members
==============================

- Annick Fabri
- Chris Timmerman
- Kristina Zoria
- Miao YU
- Roel Otten
- Saeid Abdollahi
- Van An Thuy



