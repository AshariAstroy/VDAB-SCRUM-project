using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using ScrumVerkoopService;
using ScrumVerkoopWeb.Security;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<PrulariaComContext>(
        options => options.UseMySQL(
         builder.Configuration.GetConnectionString("PrulariaComConnection"),
                           x => x.MigrationsAssembly("ScrumVerkoopData")));
builder.Services.AddTransient<AccountService>();
builder.Services.AddTransient<SecurityManager>();
builder.Services.AddTransient<ISecuritygroepRepository, SecuritygroepRepository>();
builder.Services.AddTransient<IPersoneelslidRepository, PersoneelslidRepository>();
builder.Services.AddTransient<IAuthorizationHandler, SecuritygroepMembershipHandler>();
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("PersoneelslidVanCwebsite", policy
    => policy.Requirements.Add(new SecuritygroepMembershipRequirement(
    new List<string>() { "Cwebsite" })));
});
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.LogoutPath = "/Account/LogOff";
        options.ReturnUrlParameter = "ReturnUrl";
    });
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IBestellingRepository, BestellingRepository>();
builder.Services.AddScoped<BestellingService>();
builder.Services.AddScoped<IKlantRepository, KlantRepository>();
builder.Services.AddScoped<KlantService>();
builder.Services.AddScoped<IAdresRepository, AdresRepository>();
builder.Services.AddScoped<AdresService>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
