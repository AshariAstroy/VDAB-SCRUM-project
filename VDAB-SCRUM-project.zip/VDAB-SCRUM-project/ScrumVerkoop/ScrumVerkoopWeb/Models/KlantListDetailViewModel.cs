﻿namespace ScrumVerkoopWeb.Models
{
    public class KlantListDetailViewModel
    {
        public int KlantId { get; set; }
        public string Naam { get; set; }
        public string Type { get; set; }
        public string Disabled { get; set; }

    }
}
