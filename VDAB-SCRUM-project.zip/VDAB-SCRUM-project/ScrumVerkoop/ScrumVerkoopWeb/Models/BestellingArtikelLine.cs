﻿namespace ScrumVerkoopWeb.Models;

public class BestellingArtikelLine
{
    public int BestellijnId { get; set; }
    public string Naam { get; set; } = "";
    public string Ean { get; set; } = "";
    public int AantalBesteld { get; set; }
    public int OrigineelGeannuleerd { get; set; }
    public int AantalGeannuleerd { get; set; }
    public decimal Prijs { get; set; }
}