﻿namespace ScrumVerkoopWeb.Models
{
    public class KlantenListViewModel
    {
        public List<KlantListDetailViewModel> Klanten { get; set; }
        
        // Pagination properties
        public int CurrentPage { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public int TotalItems { get; set; }
        public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize);
        public bool HasPreviousPage => CurrentPage > 1;
        public bool HasNextPage => CurrentPage < TotalPages;
        
        // Filter properties
        public string? SearchValue { get; set; }
        public string? TypeValue { get; set; }
        public string? ActiefValue { get; set; }
        public bool LopendChecked { get; set; }
    }
}