﻿namespace ScrumVerkoopWeb.Models
{
    public class KlantDetailViewModel
    {
        public int Id { get; set; }
        public int KlantId { get; set; }
        public string Naam { get; set; } = "";
        public string Type { get; set; } = ""; // Natuurlijk persoon of rechtspersoon
        public int AccountId { get; set; }
        public string Disabled { get; set; }

        // Facturatieadres
        public string FacturatieStraat { get; set; } = "";
        public string FacturatieHuisNummer { get; set; } = "";
        public string? FacturatieBus { get; set; }
        public string FacturatiePostcode { get; set; } = "";
        public string FacturatiePlaats { get; set; } = "";

        // Leveringsadres
        public string LeveringsStraat { get; set; } = "";
        public string LeveringsHuisNummer { get; set; } = "";
        public string? LeveringsBus { get; set; }
        public string LeveringsPostcode { get; set; } = "";
        public string LeveringsPlaats { get; set; } = "";

        public List<ContactPersoonViewModel> ContactPersonen { get; set; } = new List<ContactPersoonViewModel>();
        public List<BestellingListLine> Bestellingen { get; set; } = new List<BestellingListLine>();
    }
}
