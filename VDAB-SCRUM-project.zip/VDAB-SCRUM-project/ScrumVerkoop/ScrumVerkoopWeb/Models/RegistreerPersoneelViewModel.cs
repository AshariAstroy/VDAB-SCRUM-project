﻿using Microsoft.AspNetCore.Mvc.DataAnnotations;
using System.ComponentModel.DataAnnotations;
namespace ScrumVerkoopWeb.Models
{
    public class RegistreerPersoneelViewModel
    {
        [Required]
        public string Voornaam { get; set; }
        [Required]
        public string FamilieNaam { get; set; }
        [Required, EmailAddress]
        public string EmailAdres { get; set; }
        [Required]
        public string Paswoord { get; set; }
        [Required, Compare("Paswoord")]
        public string HerhaalPaswoord { get; set; }
    }
}
