﻿namespace ScrumVerkoopWeb.Models;

public class ContactPersoonViewModel
{
    public int Id { get; set; }
    public int KlantId { get; set; }
    public string Naam { get; set; } = "";  // Voornaam + Familienaam
    public string Functie { get; set; }
    public string Telefoon { get; set; } = "";
    public string Email { get; set; }
    public int AccountId { get; set; }
    public string Disabled { get; set; }
}