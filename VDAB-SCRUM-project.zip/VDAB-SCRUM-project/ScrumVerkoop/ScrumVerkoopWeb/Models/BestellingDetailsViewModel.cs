﻿using ScrumVerkoopData.Models;

namespace ScrumVerkoopWeb.Models;

public class BestellingDetailsViewModel
{
    public int BestelId { get; set; }
    public DateTime Besteldatum { get; set; }
    public int BestellingsStatusId { get; set; }
    public bool Annulatie { get; set; }

    public int KlantId { get; set; }
    public string CustomerVoornaam { get; set; } = "";
    public string CustomerFamilienaam { get; set; } = "";
    public string? CustomerBedrijfsnaam { get; set; }

    public string ContactVoornaam { get; set; } = "";
    public string ContactFamilienaam { get; set; } = "";

    public string Betaalwijze { get; set; } = "";
    public string? Betalingscode { get; set; }
    public string BestellingStatus { get; set; } = "";
    public bool ActiecodeGebruikt { get; set; }

    public string? ActiecodeNaam { get; set; }

    //public string FacturatieAdresVolledig { get; set; } = "";
    public string FacturatieStraat { get; set; } = "";
    public string FacturatieHuisNummer { get; set; } = "";
    public string? FacturatieBus { get; set; }
    public string FacturatiePostcode { get; set; } = "";
    public string FacturatiePlaats { get; set; } = "";
    //public string LeveringsAdresVolledig { get; set; } = "";
    public string LeveringsStraat { get; set; } = "";
    public string LeveringsHuisNummer { get; set; } = "";
    public string? LeveringsBus { get; set; }
    public Plaats LeveringsPlaats { get; set; }
    public int OldLeveringsPlaatsId { get; set; }
    public string OldLeveringsStraat { get; set; } = "";
    public string OldLeveringsHuisNummer { get; set; } = "";
    public string? OldLeveringsBus { get; set; }
    public int LeveringsPlaatsId { get; set; }
    public List<Plaats> Plaatsen { get; set; }
    //public string LeveringsPostcode { get; set; } = "";
    //public string LeveringsPlaats { get; set; } = "";
    public string LeveringsPostcode { get; set; } = "";
    public string LeveringsPlaatsNaam { get; set; } = "";

    public List<BestellingArtikelLine> Artikels { get; set; } = new List<BestellingArtikelLine>();
}




