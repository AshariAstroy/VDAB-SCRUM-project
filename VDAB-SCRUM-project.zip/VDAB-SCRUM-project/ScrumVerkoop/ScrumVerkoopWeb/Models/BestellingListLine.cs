﻿
using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;

namespace ScrumVerkoopWeb.Models;

public class BestellingListLine
{

    public int BestelId { get; set; }

    public DateOnly Besteldatum { get; set; }

    public int KlantId { get; set; }

    public bool Annulatie { get; set; }

    public string CustomerName { get; set; }

    public bool IsCustomerCompany { get; set; }

    public string BestellingStatusNaam { get; set; } = null!;

    public int BestellingsStatusId { get; set; }

    public int AantalArtikels { get; set; }

    public bool Betaald { get; set; }
}
