﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ScrumVerkoopData.Models;
using System.ComponentModel.DataAnnotations;

namespace ScrumVerkoopWeb.Models
{
    public class AdresViewModel
    {
        public int KlantId { get; set; }
        public int BestelId { get; set; }
        public int AdresId { get; set; }
        [Required(ErrorMessage = "Straat is verplicht.")]
        [StringLength(100, ErrorMessage = "Straat mag maximaal 100 tekens bevatten.")]
        public string Straat { get; set; }

        [Required(ErrorMessage = "Huisnummer is verplicht.")]
        [StringLength(10, ErrorMessage = "Huisnummer mag maximaal 10 tekens bevatten.")]
        public string HuisNr { get; set; }

        [StringLength(10, ErrorMessage = "Bus mag maximaal 10 tekens bevatten.")]
        public string? Bus { get; set; }
        public int PlaatsId { get; set; }
        [ValidateNever]
        public List<Plaats> Plaatsen { get; set; } = new List<Plaats>();

        public string AdresType { get; set; }
    }
}
