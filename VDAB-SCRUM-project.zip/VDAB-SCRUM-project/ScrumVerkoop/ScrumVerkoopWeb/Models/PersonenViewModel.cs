﻿using System.Collections.Generic;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopWeb.Models
{
    public class PersonenViewModel
    {
        public List<NatuurlijkePersoon> NatuurlijkePersonen { get; set; }
        public List<Rechtspersoon> Rechtspersonen { get; set; }
    }
}
