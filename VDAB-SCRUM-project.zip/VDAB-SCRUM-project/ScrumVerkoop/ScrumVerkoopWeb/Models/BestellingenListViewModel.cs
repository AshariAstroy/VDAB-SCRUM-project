﻿using ScrumVerkoopData;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopWeb.Models;

public class BestellingenListViewModel
{
    public IEnumerable<BestellingListLine> BestellingenList { get; set; }
    
    // Pagination properties
    public int CurrentPage { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public int TotalItems { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize);
    public bool HasPreviousPage => CurrentPage > 1;
    public bool HasNextPage => CurrentPage < TotalPages;
    public string? SearchValue { get; set; }
}
