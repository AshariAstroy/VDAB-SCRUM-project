﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using ScrumVerkoopService;
using ScrumVerkoopWeb.Models;

namespace ScrumVerkoopWeb.Controllers;
[Authorize(Policy = "PersoneelslidVanCwebsite")]
public class KlantController : Controller
{
    private readonly KlantService _service;
    private readonly AdresService _adresService;
    public KlantController(KlantService service, AdresService adresService)
    {
        _service = service;
        _adresService = adresService;
    }
    public async Task<IActionResult> Detail(int id)
	{
		var klant = _adresService.GetKlantById(id);
		if (klant == null) return NotFound();

		var contactPersonen = _service.GetContactPersonenByKlantId(klant.KlantId);
        var bestellingen = _service.GetBestellingenByKlantId(klant.KlantId);

        var viewModel = new KlantDetailViewModel
		{
			Id = klant.KlantId,
            KlantId = klant.KlantId,
            Naam = klant.Rechtspersonen?.Naam ??
				   $"{klant.Natuurlijkepersonen?.Voornaam} {klant.Natuurlijkepersonen?.Familienaam}",
			Type = klant.Rechtspersonen != null ? "Rechtspersoon" : "Natuurlijk persoon",
            AccountId = klant.Natuurlijkepersonen != null ? klant.Natuurlijkepersonen.GebruikersAccountId : 0,
            Disabled = klant.Natuurlijkepersonen == null
                    ? ""
                    : (klant.Natuurlijkepersonen.GebruikersAccount.Disabled ? "Disabled" : "Active"),

            // Facturatieadres
            FacturatieStraat = klant.FacturatieAdres?.Straat ?? "",
			FacturatieHuisNummer = klant.FacturatieAdres?.HuisNummer ?? "",
			FacturatieBus = klant.FacturatieAdres?.Bus,
			FacturatiePostcode = klant.FacturatieAdres?.Plaats?.Postcode.ToString() ?? "",
			FacturatiePlaats = klant.FacturatieAdres?.Plaats?.Naam ?? "",

			// Leveringsadres
			LeveringsStraat = klant.LeveringsAdres?.Straat ?? "",
			LeveringsHuisNummer = klant.LeveringsAdres?.HuisNummer ?? "",
			LeveringsBus = klant.LeveringsAdres?.Bus,
			LeveringsPostcode = klant.LeveringsAdres?.Plaats?.Postcode.ToString() ?? "",
			LeveringsPlaats = klant.LeveringsAdres?.Plaats?.Naam ?? "",

			// Contactpersonen
			ContactPersonen = contactPersonen.Select(cp => new ContactPersoonViewModel
			{
				Id = cp.ContactpersoonId,
				KlantId = cp.KlantId,
				Naam = $"{cp.Voornaam} {cp.Familienaam}",
				Functie = cp.Functie,           
				Email = cp.GebruikersAccount?.Emailadres,
                AccountId = cp.GebruikersAccountId,
                Disabled = cp.GebruikersAccount.Disabled ? "Disabled" : "Active"
            }).ToList()?? new List<ContactPersoonViewModel>(),

            // Bestellingen
            Bestellingen = bestellingen.Select(b => new BestellingListLine
            {
                BestelId = b.BestelId,
                Besteldatum = DateOnly.FromDateTime(b.Besteldatum),
                KlantId = b.KlantId,
                Annulatie = b.Annulatie,
                Betaald = b.Betaald,

                BestellingsStatusId = b.BestellingsStatusId,
                BestellingStatusNaam = b.BestellingsStatus.Naam,

                AantalArtikels = b.Bestellijnen?.Sum(l => l.AantalBesteld - l.AantalGeannuleerd) ?? 0,

                CustomerName = b.Klant.Rechtspersonen != null
        ? b.Klant.Rechtspersonen.Naam
        : $"{b.Klant.Natuurlijkepersonen?.Voornaam} {b.Klant.Natuurlijkepersonen?.Familienaam}",

                IsCustomerCompany = b.Klant.Rechtspersonen != null
            }).ToList()


        };

		return View(viewModel);
	}

    public IActionResult Index(string search = null, string type = null, string actief = null, bool lopend = false, int page = 1, int pageSize = 10)
    {
        var (klanten, totalCount) = _service.GetKlantenPaginated(page, pageSize, search, type, actief, lopend);

        // Map to view model
        var viewModel = new KlantenListViewModel
        {
            Klanten = klanten.Select(klant => new KlantListDetailViewModel
            {
                KlantId = klant.KlantId,
                Naam = klant.Natuurlijkepersonen != null
                    ? $"{klant.Natuurlijkepersonen.Voornaam} {klant.Natuurlijkepersonen.Familienaam}"
                    : klant.Rechtspersonen?.Naam ?? "",
                Type = klant.Natuurlijkepersonen != null ? "Natuurlijkpersoon" : "Rechtspersoon",
                Disabled = klant.Natuurlijkepersonen == null
                    ? ""
                    : klant.Natuurlijkepersonen.GebruikersAccount?.Disabled == true ? "Disabled" : "Active"
            }).ToList(),
            CurrentPage = page,
            PageSize = pageSize,
            TotalItems = totalCount,
            SearchValue = search,
            TypeValue = type,
            ActiefValue = actief,
            LopendChecked = lopend
        };

        // Dropdowns and checkbox states
        ViewBag.TypeOptions = new List<SelectListItem>
        {
            new SelectListItem("Bedrijf/Persoon", ""),
            new SelectListItem("Bedrijf", "bedrijf"),
            new SelectListItem("Persoon", "persoon")
        };
        ViewBag.ActiefOptions = new List<SelectListItem>
        {
            new SelectListItem("Active/Disabled", ""),
            new SelectListItem("Active", "active"),
            new SelectListItem("Disabled", "disabled")
        };

        // Remember choices in UI
        ViewBag.TypeValue = type ?? "";
        ViewBag.ActiefValue = actief ?? "";
        ViewBag.LopendChecked = lopend;
        ViewBag.SearchValue = search ?? "";

        return View(viewModel);
    }
    // Adres features
    [HttpGet]
    public IActionResult UpdateAdres(int klantId, string adresType)
    {
        var klant = _adresService.GetKlantById(klantId);
        if (klant == null) return NotFound();

        Adres adres = adresType.ToLower() switch
        {
            "facturatie" => _adresService.GetKlantFacturatieAdresById(klant.FacturatieAdresId),
            "levering" => _adresService.GetKlantBestelingAdresById(klant.LeveringsAdresId),
            _ => null
        };
        if (adres == null) return NotFound();

        var viewModel = new AdresViewModel
        {
            KlantId = klant.KlantId,
            AdresId = adres.AdresId,
            Straat = adres.Straat,
            HuisNr = adres.HuisNummer,
            Bus = adres.Bus,
            Plaatsen = _adresService.GetAllPlaatsen(),
            PlaatsId = adres.PlaatsId,
            AdresType = adresType
        };
        return View(viewModel);
    }

    [HttpPost]
    public IActionResult UpdateAdres(AdresViewModel viewModel)
    {
        if (!ModelState.IsValid)
        {
            viewModel.Plaatsen = _adresService.GetAllPlaatsen();
            return View(viewModel);
        }

        var adres = _adresService.CheckAdres(viewModel.Straat, viewModel.HuisNr, viewModel.Bus, viewModel.PlaatsId);
        if (adres == null)
        {
            _adresService.CreateAdres(viewModel.Straat, viewModel.HuisNr, viewModel.Bus, viewModel.PlaatsId);
            adres = _adresService.CheckAdres(viewModel.Straat, viewModel.HuisNr, viewModel.Bus, viewModel.PlaatsId);
        }

        var klant = _adresService.GetKlantById(viewModel.KlantId);
        if (klant == null) return NotFound();

        if (viewModel.AdresType == "facturatie")
            klant.FacturatieAdresId = adres.AdresId;
        else if (viewModel.AdresType == "levering")
            klant.LeveringsAdresId = adres.AdresId;

        _adresService.UpdateAdres(klant);

        TempData["SuccessMessage"] = "Adreswijziging succesvol opgeslagen.";
        return RedirectToAction("Detail", new { id = klant.KlantId });
    }
    public IActionResult BevestigAccountStatus(int id, int klantId)
    {
        GebruikerAccount account = _service.GetGebruikAccount(id);
        ViewBag.klantId = klantId;
        return View(account);
    }
    [HttpPost]
    public IActionResult ChangeContactStatus(int id, int klantId)
    {
        _service.ChangeContactStatus(id);
        return RedirectToAction("Detail", new { id = klantId });
    }
}

