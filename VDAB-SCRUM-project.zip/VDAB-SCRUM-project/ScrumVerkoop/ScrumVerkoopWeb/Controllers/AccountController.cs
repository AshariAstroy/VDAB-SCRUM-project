﻿using Microsoft.AspNetCore.Mvc;
using ScrumVerkoopService;
using ScrumVerkoopWeb.Security;
using ScrumVerkoopWeb.Models;
using Microsoft.AspNetCore.Identity;
using ScrumVerkoopData.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ScrumVerkoopWeb.Controllers
{
    public sealed class AccountController(AccountService accountService, SecurityManager securityManager) : Controller
    {
        [HttpGet]
        public IActionResult LogIn(string returnUrl)
        {
            var loginModel = new LoginViewModel()
            {
                ReturnUrl = returnUrl
            };
            //als er geen returnUrl is wordt de gebruiker naar de homepagina gestuurd
            loginModel.ReturnUrl ??= Url.Content("~/");
            return View(nameof(LogIn), loginModel);
        }
        [HttpPost]
        public async Task<ActionResult> LogIn(LoginViewModel loginModel)
        {
            if (!ModelState.IsValid)
                return View(nameof(LogIn), loginModel);
            var personeelslid = await accountService.Login(loginModel.Emailadres, loginModel.Paswoord);
            if (personeelslid is null ||
            (personeelslid.InDienst.HasValue && !personeelslid.InDienst.Value) ||
            personeelslid.PersoneelslidAccount.Disabled)
            {
                loginModel.ErrorMessage = "Deze gebruiker/paswoord combinatie is fout.";
                return View(nameof(LogIn), loginModel);
            }
            //await securityManager.SignIn(this.HttpContext, personeelslid);
            //met persistent cookie
            await securityManager.SignIn(this.HttpContext, personeelslid,
            loginModel.IsCookiePersistent);
            return LocalRedirect(loginModel.ReturnUrl);
        }
        public async Task<IActionResult> Logoff()
        {
            await securityManager.SignOut(HttpContext);
            return RedirectToAction(nameof(LogIn));
        }
        public IActionResult AccessDenied()
        {
            return View(nameof(AccessDenied));
        }
        [Authorize]
        public async Task<IActionResult> Account()
        {
            int personeelsLidId = 0;
            foreach (var claim in User.Claims)
            {
                if (claim.Type == "PersoneelslidId")
                {
                    personeelsLidId = int.Parse(claim.Value);
                }
            }
            return View(await accountService.GetPersoneelslid(personeelsLidId));
        }
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Account(int personeelslidId, string currentPW, string newPw, string repeatPw)
        {
            PersoneelsLid personeelsLid = await accountService.GetPersoneelslid(personeelslidId);
            if (!String.IsNullOrWhiteSpace(currentPW) && !String.IsNullOrWhiteSpace(newPw) && !String.IsNullOrWhiteSpace(repeatPw))
            {
                if (newPw == repeatPw)
                {
                    if (accountService.VerifyPaswoord(currentPW, personeelsLid.PersoneelslidAccount.Paswoord))
                    {
                        await accountService.ChangePassword(personeelsLid.PersoneelslidAccount.PersoneelslidAccountId, newPw);
                        ViewBag.ErrorMsg = "Wachtwoord is gewijzigd";
                    }
                    else
                    {
                        ViewBag.ErrorMsg = "Huidige wachtwoord is niet juist!";
                    }
                }
                else
                {
                    ViewBag.ErrorMsg = "Nieuwe wachtwoord niet gelijk!";
                }
                personeelsLid = personeelsLid = await accountService.GetPersoneelslid(personeelslidId);
            }
            else
            {
                ViewBag.ErrorMsg = "Vul alle velden in!";
            }
                return View(personeelsLid);
        }
        public IActionResult Registreer()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Registreer(RegistreerPersoneelViewModel vModel)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(Registreer), vModel);
            }
            PersoneelsLid nieuwePersoneelsLid = new PersoneelsLid
            {
                Voornaam = vModel.Voornaam,
                Familienaam = vModel.FamilieNaam,
                InDienst = true,
                PersoneelslidAccount = new PersoneelsLidAccount
                {
                    Emailadres = vModel.EmailAdres,
                    Paswoord = vModel.Paswoord,
                    Disabled = false
                }
            };
            PersoneelsLid personeelsLid = await accountService.Registreer(nieuwePersoneelsLid);
            if (personeelsLid == null)
            {
                return View(nameof(Registreer), vModel);
            }
            return RedirectToAction(nameof(LogIn));
        }
    }
}
