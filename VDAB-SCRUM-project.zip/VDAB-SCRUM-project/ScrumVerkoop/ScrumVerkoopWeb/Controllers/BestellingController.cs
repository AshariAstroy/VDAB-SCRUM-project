﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScrumVerkoopData.Models;
using ScrumVerkoopService;
using ScrumVerkoopWeb.Models;

namespace ScrumVerkoopWeb.Controllers
{
    [Authorize(Policy = "PersoneelslidVanCwebsite")]
    public class BestellingController : Controller
    {
        private readonly ILogger<BestellingController> _logger;
        private readonly BestellingService _service;
        public BestellingController(ILogger<BestellingController> logger, BestellingService service)
        {
            _logger = logger;
            _service = service;
        }

        /* ================================================================================================================= */

        private string GetCustomerName(Klant klant)
        {
            if (klant.Natuurlijkepersonen != null)
                return klant.Natuurlijkepersonen.Voornaam + " " + klant.Natuurlijkepersonen.Familienaam;

            if (klant.Rechtspersonen != null)
                return klant.Rechtspersonen.Naam;

            return "Onbekend";
        }

        public IActionResult Index(int page = 1, int pageSize = 10)
        {
            var (bestellingen, totalCount) = _service.GetBestellingenPaginated(page, pageSize);

			var vModel = new BestellingenListViewModel
			{
				BestellingenList = bestellingen.Select(b => new BestellingListLine
				{
					BestelId = b.BestelId,
					Besteldatum = DateOnly.FromDateTime(b.Besteldatum),
					KlantId = b.KlantId,
                    CustomerName = GetCustomerName(b.Klant),
					IsCustomerCompany = b.Klant.Rechtspersonen != null, // true als bedrijf
					BestellingStatusNaam = b.BestellingsStatus.Naam,
					AantalArtikels = b.Bestellijnen.Sum(l => l.AantalBesteld) - b.Bestellijnen.Sum(l => l.AantalGeannuleerd),
					Annulatie = b.Annulatie,
					BestellingsStatusId = b.BestellingsStatusId,
					Betaald = b.Betaald
				}).ToList(),
				CurrentPage = page,
				PageSize = pageSize,
				TotalItems = totalCount,
			};
			return View(vModel);
		}

		public IActionResult OverdueUnpaidOrders(int page = 1, int pageSize = 10)
		{
			var (bestellingen, totalCount) = _service.GetOverdueUnpaidBestellingenPaginated(page, pageSize);

			var vModel = new BestellingenListViewModel
			{
				BestellingenList = bestellingen.Select(b => new BestellingListLine
				{
					BestelId = b.BestelId,
					Besteldatum = DateOnly.FromDateTime(b.Besteldatum),
					CustomerName = GetCustomerName(b.Klant),
					IsCustomerCompany = b.Klant.Rechtspersonen != null, // true als bedrijf
					BestellingStatusNaam = b.BestellingsStatus.Naam,
					AantalArtikels = b.Bestellijnen.Sum(l => l.AantalBesteld) - b.Bestellijnen.Sum(l => l.AantalGeannuleerd),
					Annulatie = b.Annulatie,
                    KlantId = b.KlantId,
                    BestellingsStatusId = b.BestellingsStatusId,
					Betaald = b.Betaald
				}).ToList(),
				CurrentPage = page,
				PageSize = pageSize,
				TotalItems = totalCount,
			};
			
			ViewBag.IsFilteredView = true;
			ViewBag.FilterType = "overdue-unpaid";
			
			return View("Index", vModel);
		}

		public IActionResult OverdueUndeliveredOrders(int page = 1, int pageSize = 10)
		{
			var (bestellingen, totalCount) = _service.GetOverdueUndeliveredBestellingenPaginated(page, pageSize);

			var vModel = new BestellingenListViewModel
			{
				BestellingenList = bestellingen.Select(b => new BestellingListLine
				{
					BestelId = b.BestelId,
					Besteldatum = DateOnly.FromDateTime(b.Besteldatum),
					CustomerName = GetCustomerName(b.Klant),
					IsCustomerCompany = b.Klant.Rechtspersonen != null, // true als bedrijf
					BestellingStatusNaam = b.BestellingsStatus.Naam,
					AantalArtikels = b.Bestellijnen.Sum(l => l.AantalBesteld) - b.Bestellijnen.Sum(l => l.AantalGeannuleerd),
					Annulatie = b.Annulatie,
                    KlantId = b.KlantId,
                    BestellingsStatusId = b.BestellingsStatusId,
					Betaald = b.Betaald
				}).ToList(),
				CurrentPage = page,
				PageSize = pageSize,
				TotalItems = totalCount,
			};
			
			ViewBag.IsFilteredView = true;
			ViewBag.FilterType = "overdue-undelivered";
			
			return View("Index", vModel);
		}
		/* ================================================================================================================= */

        [HttpGet]
        public async Task<IActionResult> Detail(int id)
        {
            var bestelling = await _service.GetByIdAsync(id);
            if (bestelling == null)
            {
                return NotFound();
            }

            var vModel = new BestellingDetailsViewModel
            {
                BestelId = bestelling.BestelId,
                Besteldatum = bestelling.Besteldatum,
                Annulatie = bestelling.Annulatie,
                BestellingsStatusId = bestelling.BestellingsStatusId,

				KlantId = bestelling.KlantId,	
                CustomerVoornaam = bestelling.Klant?.Natuurlijkepersonen?.Voornaam ?? "",
				CustomerFamilienaam = bestelling.Klant?.Natuurlijkepersonen?.Familienaam ?? "",
				CustomerBedrijfsnaam = bestelling.Klant?.Rechtspersonen?.Naam,

                ContactVoornaam = bestelling.Voornaam,
                ContactFamilienaam = bestelling.Familienaam,

                Betaalwijze = bestelling.Betaalwijze?.Naam ?? "",
                Betalingscode = bestelling.Betalingscode,
                BestellingStatus = bestelling.BestellingsStatus?.Naam ?? "",
                ActiecodeGebruikt = bestelling.ActiecodeGebruikt,
                ActiecodeNaam = null,

                FacturatieStraat = bestelling.FacturatieAdres?.Straat ?? "",
                FacturatieHuisNummer = bestelling.FacturatieAdres?.HuisNummer ?? "",
                FacturatieBus = bestelling.FacturatieAdres?.Bus,
                FacturatiePostcode = bestelling.FacturatieAdres?.Plaats?.Postcode.ToString() ?? "",
                FacturatiePlaats = bestelling.FacturatieAdres?.Plaats?.Naam ?? "",

                LeveringsStraat = bestelling.LeveringsAdres?.Straat ?? "",
                LeveringsHuisNummer = bestelling.LeveringsAdres?.HuisNummer ?? "",
                LeveringsBus = bestelling.LeveringsAdres.Bus,
                LeveringsPlaats = bestelling.LeveringsAdres.Plaats,
                LeveringsPlaatsId = bestelling.LeveringsAdres.PlaatsId,

                OldLeveringsStraat = bestelling.LeveringsAdres?.Straat ?? "",
                OldLeveringsHuisNummer = bestelling.LeveringsAdres?.HuisNummer ?? "",
                OldLeveringsBus = bestelling.LeveringsAdres.Bus,
                OldLeveringsPlaatsId = bestelling.LeveringsAdres.PlaatsId,
                Plaatsen = _service.GetAllPlaatsen(),

                Artikels = bestelling.Bestellijnen.Select(l => new BestellingArtikelLine
                {
                    BestellijnId = l.BestellijnId,
                    Naam = l.Artikel?.Naam ?? "",
                    Ean = l.Artikel?.Ean ?? "",
                    AantalBesteld = l.AantalBesteld,
                    OrigineelGeannuleerd = l.AantalGeannuleerd,
                    AantalGeannuleerd = l.AantalGeannuleerd,
                    Prijs = l.Artikel?.Prijs ?? 0m
                }).ToList()
            };

            return View(vModel);
        }
        /* ================================================================================================================= */

        [HttpPost]
        public async Task<IActionResult> Detail(BestellingDetailsViewModel vModel)
        {
            if (vModel.Artikels.Any())
            {
                foreach (var artikelLine in vModel.Artikels)
                {
                    if (artikelLine.AantalGeannuleerd != artikelLine.OrigineelGeannuleerd)
                    {
                        // effectieve update van de bestelling in de database
                        _service.UpdateAantalGeannuleerd(artikelLine.BestellijnId, artikelLine.AantalGeannuleerd);
                    }
                }
            }
            if (vModel.LeveringsStraat != vModel.OldLeveringsStraat ||
                vModel.LeveringsHuisNummer != vModel.OldLeveringsHuisNummer ||
                vModel.LeveringsBus != vModel.OldLeveringsBus ||
                vModel.LeveringsPlaatsId != vModel.OldLeveringsPlaatsId)
            {
                return RedirectToAction(nameof(UpdateAdres), vModel);
            }
            return RedirectToAction(nameof(Detail), new { id = vModel.BestelId });
        }
        /* ================================================================================================================= */

		[HttpPost]
		public IActionResult Index(string name, int page = 1, int pageSize = 10)
		{
			var (bestellingen, totalCount) = _service.FilterByNamePaginated(name, page, pageSize);
			ViewBag.SearchValue = name;
			var vModel = new BestellingenListViewModel
			{
				BestellingenList = bestellingen.Select(b => new BestellingListLine
				{
					BestelId = b.BestelId,
					Besteldatum = DateOnly.FromDateTime(b.Besteldatum),
					CustomerName = GetCustomerName(b.Klant),
					IsCustomerCompany = b.Klant.Rechtspersonen != null, // true als bedrijf
					BestellingStatusNaam = b.BestellingsStatus.Naam,
					AantalArtikels = b.Bestellijnen.Sum(l => l.AantalBesteld) - b.Bestellijnen.Sum(l => l.AantalGeannuleerd),
					Annulatie = b.Annulatie,
                    KlantId = b.KlantId,
                    BestellingsStatusId = b.BestellingsStatusId,
					Betaald = b.Betaald
				}).ToList(),
				CurrentPage = page,
				PageSize = pageSize,
				TotalItems = totalCount,
				SearchValue = name
			};
			return View(vModel);
		}

        [HttpGet]
        public async Task<IActionResult> AnnulerenCheck(int bestelId)
        {
            var bestelling = await _service.GetByIdAsync(bestelId);
            if (bestelling == null)
            {
                return NotFound();
            }
            return View("Annuleer", bestelling);
        }

        [HttpPost]
        public IActionResult BestellingCancel(int bestelId)
        {
            _service.BestellingCancel(bestelId);
            return RedirectToAction(nameof(Index));
        }
        public IActionResult UpdateAdres(BestellingDetailsViewModel viewModel)
        {
            Plaats oldPlaats = _service.getPlaatsById(viewModel.OldLeveringsPlaatsId);
            Plaats plaats = _service.getPlaatsById(viewModel.LeveringsPlaatsId);
            ViewBag.OldPostcode = oldPlaats.Postcode;
            ViewBag.OldNaam = oldPlaats.Naam;
            ViewBag.Postcode = plaats.Postcode;
            ViewBag.Naam = plaats.Naam;
            return View(viewModel);
        }
        [HttpPost]
        public async Task<IActionResult> DoUpdateAdres(BestellingDetailsViewModel viewModel)
        {
            if (!String.IsNullOrWhiteSpace(viewModel.LeveringsStraat) && !String.IsNullOrWhiteSpace(viewModel.LeveringsHuisNummer))
            {
                if (viewModel.LeveringsBus == null)
                {
                    viewModel.LeveringsBus = "";
                }
                Adres adres = _service.CheckAdres(viewModel.LeveringsStraat, viewModel.LeveringsHuisNummer, viewModel.LeveringsBus, viewModel.LeveringsPlaatsId);
                if (adres == null)
                {
                    _service.CreateAdres(viewModel.LeveringsStraat, viewModel.LeveringsHuisNummer, viewModel.LeveringsBus, viewModel.LeveringsPlaatsId);
                    adres = _service.CheckAdres(viewModel.LeveringsStraat, viewModel.LeveringsHuisNummer, viewModel.LeveringsBus, viewModel.LeveringsPlaatsId);
                }
                var bestelling = await _service.GetByIdAsync(viewModel.BestelId);
                bestelling.LeveringsAdresId = adres.AdresId;
                _service.UpdateLeveringsAdres(bestelling);
            }
            return RedirectToAction(nameof(Detail), new { id = viewModel.BestelId});
        }
    }
}
