﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using ScrumVerkoopData.Models;
using ScrumVerkoopService;
using System.Security.Claims;

namespace ScrumVerkoopWeb.Security
{
    public sealed class SecurityManager
    {
        private readonly AccountService _accountService;
        public SecurityManager(AccountService accountService)
        {
            _accountService = accountService;
        }
        public async Task SignIn(HttpContext httpContext, PersoneelsLid personeelslid)
        {
            ClaimsIdentity claimsIdentity = new(GetUserClaims(personeelslid),
            CookieAuthenticationDefaults.AuthenticationScheme);
            ClaimsPrincipal claimsPrincipal = new(claimsIdentity);
            await httpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
        }
        public async Task SignOut(HttpContext httpContext) => await httpContext.SignOutAsync();
        private IEnumerable<Claim> GetUserClaims(PersoneelsLid personeelslid)
        {
            List<Claim> claims = 
                [
                    new Claim(ClaimTypes.Name, string.Join(' ', personeelslid.Voornaam,personeelslid.Familienaam)),
                    new Claim("PersoneelslidId", personeelslid.PersoneelslidId.ToString()),
                    new Claim("PersoneelslidAccountId", personeelslid.PersoneelslidAccountId.ToString())
                ];
            //toegevoegd voor rollen + DI van de AccountService
            var securitygroepnamen = _accountService.GetSecuritygroepenVanPersoneelslid(
            personeelslid.PersoneelslidId).Result.Select(sg => sg.Naam);
            claims.AddRange(securitygroepnamen
            .Select(sg => new Claim(ClaimTypes.Role, sg)));
            return claims;
        }
        //Telkens als de gebruiker zich aanmeldt worden een ClaimsPrincipal, een
        // ClaimsIdentity met de claims (de volledige gebruikersnaam, het personeelslidId
        // en de PersoneelslidAccountId) gecreëerd
        public async Task SignIn(HttpContext httpContext, PersoneelsLid personeelslid,
        bool isCookiePersistent)
        {
            ClaimsIdentity claimsIdentity = new(GetUserClaims(personeelslid),
            CookieAuthenticationDefaults.AuthenticationScheme);
            ClaimsPrincipal claimsPrincipal = new(claimsIdentity);
            //account wordt bijgehouden in een cookie dat vervalt als de sessie
            //afgesloten wordt
            //await httpContext.SignInAsync(
            // CookieAuthenticationDefaults.AuthenticationScheme,
            // claimsPrincipal);
            //als de gebruiker kiest om de login te behouden
            //--> persistent cookie (anders session cookie): de cookie vervalt na 60 minuten
            //zonder vervaldatum verdwijnt de cookie als je uitlogt of
            //als je de cookie in de browser handmatig verwijdert
            if (isCookiePersistent)
                await httpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal,
                new AuthenticationProperties
                {
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(60),
                    IsPersistent = true
                }
                );
            else
                await httpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
        }

    }
}
