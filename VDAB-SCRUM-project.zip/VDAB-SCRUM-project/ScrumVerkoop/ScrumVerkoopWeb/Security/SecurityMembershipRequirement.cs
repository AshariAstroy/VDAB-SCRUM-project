﻿using Microsoft.AspNetCore.Authorization;

namespace ScrumVerkoopWeb.Security
{
    public class SecuritygroepMembershipRequirement(IEnumerable<string> securitygroepen) : IAuthorizationRequirement
    {
        public IEnumerable<string> Securitygroepen => securitygroepen;
    }
}
