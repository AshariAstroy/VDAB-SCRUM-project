﻿using Microsoft.AspNetCore.Authorization;
using ScrumVerkoopService;

namespace ScrumVerkoopWeb.Security
{
    public sealed class SecuritygroepMembershipHandler(AccountService accountService) : AuthorizationHandler<SecuritygroepMembershipRequirement>
    {
        protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        SecuritygroepMembershipRequirement requirement)
        {
            if (!context.User.HasClaim(c => c.Type == "PersoneelslidId"))
                return Task.CompletedTask;
            // PersoneelslidIdClaim
            var personeelslidIdClaim = context.User.FindFirst(
            c => c.Type == "PersoneelslidId");
            if (personeelslidIdClaim == null)
                return Task.CompletedTask;
            if (!int.TryParse(personeelslidIdClaim.Value, out int personeelslidId))
                return Task.CompletedTask;
            var personeelslid = accountService.GetPersoneelslid(personeelslidId).Result;
            // PersoneelslidAccountIdClaim
            var personeelslidAccountIdClaim = context.User.FindFirst(
            c => c.Type == "PersoneelslidAccountId");
            if (personeelslidAccountIdClaim == null)
                return Task.CompletedTask;
            int personeelslidAccountId;
            if (!int.TryParse(personeelslidAccountIdClaim.Value,
            out personeelslidAccountId))
                return Task.CompletedTask;
            //Validations
            //Personeelslid
            if (personeelslid == null ||
            (personeelslid.InDienst.HasValue && !personeelslid.InDienst.Value) ||
            personeelslid.PersoneelslidAccountId != personeelslidAccountId)
                return Task.CompletedTask;
            //PersoneelslidAccount
            var personeelslidAccount =
            accountService.GetPersoneelslidAccount(personeelslidAccountId).Result;
            if (personeelslidAccount == null || personeelslidAccount.Disabled)
                return Task.CompletedTask;
            //Securitygroepen
            var securitygroepnamen =
            accountService.GetSecuritygroepenVanPersoneelslid(personeelslidId)
            .Result.Select(sg => sg.Naam);
            if (requirement.Securitygroepen.Count() >
            requirement.Securitygroepen.Except(securitygroepnamen).Count())
                context.Succeed(requirement);
            return Task.CompletedTask;
        }
    }
}
