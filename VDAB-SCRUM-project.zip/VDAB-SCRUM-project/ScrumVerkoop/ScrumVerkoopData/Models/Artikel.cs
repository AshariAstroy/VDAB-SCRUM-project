﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class Artikel
{
    public int ArtikelId { get; set; }

    public string Ean { get; set; } = null!;

    public string Naam { get; set; } = null!;

    public string Beschrijving { get; set; } = null!;

    public decimal Prijs { get; set; }

    public int GewichtInGram { get; set; }

    public int Bestelpeil { get; set; }

    public int Voorraad { get; set; }

    public int MinimumVoorraad { get; set; }

    public int MaximumVoorraad { get; set; }

    public int Levertijd { get; set; }

    public int AantalBesteldLeverancier { get; set; }

    public int MaxAantalInMagazijnPlaats { get; set; }

    public int LeveranciersId { get; set; }

    public virtual ICollection<ArtikelLeveranciersInfolijn> Artikelleveranciersinfolijnens { get; set; } = new List<ArtikelLeveranciersInfolijn>();

    public virtual ICollection<Bestellijn> Bestellijnens { get; set; } = new List<Bestellijn>();

    public virtual ICollection<InkomendeLeveringsLijn> Inkomendeleveringslijnens { get; set; } = new List<InkomendeLeveringsLijn>();

    public virtual Leverancier Leveranciers { get; set; } = null!;

    public virtual ICollection<Magazijnplaats> Magazijnplaatsens { get; set; } = new List<Magazijnplaats>();

    public virtual ICollection<Veelgesteldevragenartikel> Veelgesteldevragenartikels { get; set; } = new List<Veelgesteldevragenartikel>();

    public virtual ICollection<Wishlistitem> Wishlistitems { get; set; } = new List<Wishlistitem>();

    public virtual ICollection<Categorie> Categories { get; set; } = new List<Categorie>();
}
