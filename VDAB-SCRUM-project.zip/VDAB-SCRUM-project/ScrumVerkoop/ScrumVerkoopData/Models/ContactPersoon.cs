﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class ContactPersoon
{
    public int ContactpersoonId { get; set; }

    public string Voornaam { get; set; } = null!;

    public string Familienaam { get; set; } = null!;

    public string Functie { get; set; } = null!;

    public int KlantId { get; set; }

    public int GebruikersAccountId { get; set; }

    public virtual GebruikerAccount GebruikersAccount { get; set; } = null!;

    public virtual Rechtspersoon Klant { get; set; } = null!;
}
