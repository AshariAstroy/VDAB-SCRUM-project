﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class Securitygroep
{
    public int SecurityGroepId { get; set; }

    public string Naam { get; set; } = null!;

    public virtual ICollection<PersoneelsLid> Personeelslids { get; set; } = new List<PersoneelsLid>();
}
