﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class Rechtspersoon
{
    public int KlantId { get; set; }

    public string Naam { get; set; } = null!;

    public string BtwNummer { get; set; } = null!;

    public virtual ICollection<ContactPersoon> Contactpersonen { get; set; } = new List<ContactPersoon>();

    public virtual Klant Klant { get; set; } = null!;
}
