﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class ChatGespreek
{
    public int ChatgesprekId { get; set; }

    public int GebruikersAccountId { get; set; }

    public virtual ICollection<ChatGesprekLijn> Chatgespreklijnens { get; set; } = new List<ChatGesprekLijn>();

    public virtual GebruikerAccount GebruikersAccount { get; set; } = null!;
}
