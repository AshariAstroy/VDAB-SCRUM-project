﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class InkomendeLevering
{
    public int InkomendeLeveringsId { get; set; }

    public int LeveranciersId { get; set; }

    public string LeveringsbonNummer { get; set; } = null!;

    public DateTime Leveringsbondatum { get; set; }

    public DateTime LeverDatum { get; set; }

    public int OntvangerPersoneelslidId { get; set; }

    public virtual ICollection<InkomendeLeveringsLijn> Inkomendeleveringslijnens { get; set; } = new List<InkomendeLeveringsLijn>();

    public virtual Leverancier Leveranciers { get; set; } = null!;

    public virtual PersoneelsLid OntvangerPersoneelslid { get; set; } = null!;
}
