﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class Klantreview
{
    public int KlantenReviewId { get; set; }

    public string Nickname { get; set; } = null!;

    public int Score { get; set; }

    public string? Commentaar { get; set; }

    public DateTime Datum { get; set; }

    public int BestellijnId { get; set; }

    public virtual Bestellijn Bestellijn { get; set; } = null!;
}
