﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class InkomendeLeveringsLijn
{
    public int InkomendeLeveringsId { get; set; }

    public int ArtikelId { get; set; }

    public int AantalGoedgekeurd { get; set; }

    public int AantalTeruggestuurd { get; set; }

    public int MagazijnPlaatsId { get; set; }

    public virtual Artikel Artikel { get; set; } = null!;

    public virtual InkomendeLevering InkomendeLeverings { get; set; } = null!;

    public virtual Magazijnplaats MagazijnPlaats { get; set; } = null!;
}
