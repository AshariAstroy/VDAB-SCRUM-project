﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class BestellingsStatus
{
    public int BestellingsStatusId { get; set; }

    public string Naam { get; set; } = null!;

    public virtual ICollection<Bestelling> Bestellingens { get; set; } = new List<Bestelling>();
}
