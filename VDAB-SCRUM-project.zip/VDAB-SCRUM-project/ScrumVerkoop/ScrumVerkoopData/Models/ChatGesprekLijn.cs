﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class ChatGesprekLijn
{
    public int ChatgesprekLijnId { get; set; }

    public int ChatgesprekId { get; set; }

    public string Bericht { get; set; } = null!;

    public DateTime Tijdstip { get; set; }

    public int? GebruikersAccountId { get; set; }

    public int? PersoneelslidAccountId { get; set; }

    public virtual ChatGespreek Chatgesprek { get; set; } = null!;

    public virtual GebruikerAccount? GebruikersAccount { get; set; }

    public virtual PersoneelsLidAccount? PersoneelslidAccount { get; set; }
}
