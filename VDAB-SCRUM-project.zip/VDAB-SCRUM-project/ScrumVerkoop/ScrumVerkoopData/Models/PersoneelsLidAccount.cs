﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class PersoneelsLidAccount
{
    public int PersoneelslidAccountId { get; set; }

    public string Emailadres { get; set; } = null!;

    public string Paswoord { get; set; } = null!;

    public bool Disabled { get; set; }

    public virtual ICollection<ChatGesprekLijn> Chatgespreklijnen { get; set; } = new List<ChatGesprekLijn>();

    public virtual PersoneelsLid Personeelslid { get; set; }
}
