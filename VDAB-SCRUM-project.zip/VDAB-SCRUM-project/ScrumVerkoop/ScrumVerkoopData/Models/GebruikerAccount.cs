﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class GebruikerAccount
{
    public int GebruikersAccountId { get; set; }

    public string Emailadres { get; set; } = null!;

    public string Paswoord { get; set; } = null!;

    public bool Disabled { get; set; }

    public virtual ICollection<ChatGespreek> Chatgesprekken { get; set; } = new List<ChatGespreek>();

    public virtual ICollection<ChatGesprekLijn> Chatgespreklijnen { get; set; } = new List<ChatGesprekLijn>();

    public virtual ICollection<ContactPersoon> Contactpersonen { get; set; } = new List<ContactPersoon>();

    public virtual ICollection<NatuurlijkePersoon> Natuurlijkepersonen { get; set; } = new List<NatuurlijkePersoon>();

    public virtual ICollection<Wishlistitem> Wishlistitem { get; set; } = new List<Wishlistitem>();
}
