﻿using System;
using System.Collections.Generic;

namespace ScrumVerkoopData.Models;

public partial class UitgaandeleveringsStatus
{
    public int UitgaandeLeveringsStatusId { get; set; }

    public string Naam { get; set; } = null!;

    public virtual ICollection<Uitgaandelevering> Uitgaandeleveringen { get; set; } = new List<Uitgaandelevering>();
}
