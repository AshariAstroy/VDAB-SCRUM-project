﻿using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public class KlantRepository : IKlantRepository
    {
        private readonly PrulariaComContext _context;

        public KlantRepository(PrulariaComContext context)
        {
            _context = context;
        }
        public Klant? GetKlantById(int id)
        {
            return _context.Klantens
                .Include(k => k.FacturatieAdres).ThenInclude(a => a.Plaats)
                .Include(k => k.LeveringsAdres).ThenInclude(a => a.Plaats)
                .Include(k => k.Natuurlijkepersonen).ThenInclude(n => n.GebruikersAccount)
                .Include(k => k.Rechtspersonen)  
                .FirstOrDefault(k => k.KlantId == id);
        }
        public async Task<Klant?> GetByIdAsync(int id)
        {
            return await _context.Klantens
                .Include(k => k.Natuurlijkepersonen).ThenInclude(n => n.GebruikersAccount)
                .Include(k => k.Rechtspersonen)
                .Include(k => k.Bestellingen)
                    .ThenInclude(b => b.BestellingsStatus)
                .Include(k => k.Bestellingen)
                    .ThenInclude(b => b.Bestellijnen)
                        .ThenInclude(l => l.Artikel)
                .FirstOrDefaultAsync(k => k.KlantId == id);
        }
        public List<Klant> GetAllKlanten()
        {
            return _context.Klantens
                .Include(k => k.Natuurlijkepersonen.GebruikersAccount)
                .Include(k => k.Rechtspersonen)
                .Include(k => k.Bestellingen)
                .ToList();
        }
        public List<Klant> SearchByNaam(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return GetAllKlanten();
            }
            return _context.Klantens
                .Include(k => k.Natuurlijkepersonen.GebruikersAccount)
                .Include(k => k.Rechtspersonen)
                .Where(k => (k.Natuurlijkepersonen.Voornaam.ToLower().Contains(name.ToLower()) || k.Natuurlijkepersonen.Familienaam.ToLower().Contains(name.ToLower())) ||
                            (k.Natuurlijkepersonen.Voornaam.ToLower() + " " + k.Natuurlijkepersonen.Familienaam.ToLower()).Contains(name.ToLower()) ||
                            (k.Natuurlijkepersonen.Familienaam.ToLower() + " " + k.Natuurlijkepersonen.Voornaam.ToLower()).Contains(name.ToLower()) ||
                            (k.Rechtspersonen.Naam.ToLower().Contains(name.ToLower())))
                    .ToList();
        }

        //Filter klanten by Natuurlijkepersonen or Rechtspersonen
        public List<Klant> FilterByType(bool isBedrijf, List<Klant>? klanten = null)
        {
            var listToFilter = klanten ?? _context.Klantens.Include(k => k.Rechtspersonen).Include(k => k.Natuurlijkepersonen).ToList();

            if (isBedrijf)
            {
                return listToFilter.Where(k => k.Rechtspersonen != null).ToList();
            }
            else
            {
                return listToFilter.Where(k => k.Natuurlijkepersonen != null).ToList();
            }
        }

        //Filter klanten by status "Active/Disabled"
        public List<Klant> FilterByActief(bool actief, List<Klant>? klanten = null)
        {
            var listToFilter = klanten ?? _context.Klantens.Include(k => k.Natuurlijkepersonen).ThenInclude(n => n.GebruikersAccount).ToList();

            return listToFilter.Where(k => k.Natuurlijkepersonen != null && k.Natuurlijkepersonen.GebruikersAccount != null
                && k.Natuurlijkepersonen.GebruikersAccount.Disabled != actief).ToList();
        }

        //Filter by Bestelling status "Lopend"
        public List<Klant> FilterByLopendBestellingen(List<Klant>? klanten = null)
        {
            var listToFilter = klanten ?? _context.Klantens.Include(k => k.Bestellingen).ThenInclude(b => b.BestellingsStatus).ToList();

            return listToFilter.Where(k => k.Bestellingen.Any(b => b.BestellingsStatus?.Naam == "Lopend")).ToList();
        }

        public IEnumerable<ContactPersoon> GetContactPersonenByKlantId(int klantId)
        {
	        return _context.Contactpersonens
		        .Include(cp => cp.GebruikersAccount)
		        .Where(cp => cp.KlantId == klantId).ToList();
        }

        public (List<Klant> items, int totalCount) GetKlantenPaginated(int page, int pageSize, string search = null, string type = null, string actief = null, bool lopend = false)
        {
            var query = _context.Klantens
                .Include(k => k.Natuurlijkepersonen).ThenInclude(n => n.GebruikersAccount)
                .Include(k => k.Rechtspersonen)
                .Include(k => k.Bestellingen).ThenInclude(b => b.BestellingsStatus)
                .AsQueryable();

            // Apply search filter
            if (!string.IsNullOrEmpty(search))
            {
                int id;
                bool isNumeric = int.TryParse(search, out id);
                if (isNumeric)
                {
                    query = query.Where(k => k.KlantId == id);
                }
                else
                {
                    query = query.Where(k => 
                        (k.Natuurlijkepersonen != null && 
                         (k.Natuurlijkepersonen.Voornaam.ToLower().Contains(search.ToLower()) || 
                          k.Natuurlijkepersonen.Familienaam.ToLower().Contains(search.ToLower()) ||
                          (k.Natuurlijkepersonen.Voornaam.ToLower() + " " + k.Natuurlijkepersonen.Familienaam.ToLower()).Contains(search.ToLower()) ||
                          (k.Natuurlijkepersonen.Familienaam.ToLower() + " " + k.Natuurlijkepersonen.Voornaam.ToLower()).Contains(search.ToLower()))) ||
                        (k.Rechtspersonen != null && k.Rechtspersonen.Naam.ToLower().Contains(search.ToLower())));
                }
            }

            // Apply type filter
            if (!string.IsNullOrEmpty(type))
            {
                bool isBedrijf = type == "bedrijf";
                if (isBedrijf)
                {
                    query = query.Where(k => k.Rechtspersonen != null);
                }
                else
                {
                    query = query.Where(k => k.Natuurlijkepersonen != null);
                }
            }

            // Apply actief filter
            if (!string.IsNullOrEmpty(actief))
            {
                bool isActive = actief == "active";
                query = query.Where(k => k.Natuurlijkepersonen != null && 
                                        k.Natuurlijkepersonen.GebruikersAccount != null &&
                                        k.Natuurlijkepersonen.GebruikersAccount.Disabled != isActive);
            }

            // Apply lopend filter
            if (lopend)
            {
                query = query.Where(k => k.Bestellingen.Any(b => b.BestellingsStatus != null && b.BestellingsStatus.Naam == "Lopend"));
            }

            var totalCount = query.Count();
            
            var items = pageSize == -1 ? 
                query.ToList() : 
                query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            return (items, totalCount);
        }

        //Get orders in klant detail page
        public IEnumerable<Bestelling> GetBestellingenByKlantId(int klantId)
        {
            return _context.Bestellingens
                .Include(b => b.BestellingsStatus)
                .Include(b => b.Bestellijnen)
                    .ThenInclude(bl => bl.Artikel)
                .Where(b => b.KlantId == klantId)
                .ToList();
        }
        public void ChangeContactStatus(int id)
        {
            GebruikerAccount account = _context.Gebruikersaccounts.Find(id);
            if (account != null)
            {
                if (account.Disabled)
                {
                    account.Disabled = false;
                }
                else
                {
                    account.Disabled = true;
                }
                _context.Update(account);
                _context.SaveChanges();
            }
        }
        public GebruikerAccount GetGebruikAccount(int id)
        {
            return _context.Gebruikersaccounts.Find(id);
        }
    }


}
