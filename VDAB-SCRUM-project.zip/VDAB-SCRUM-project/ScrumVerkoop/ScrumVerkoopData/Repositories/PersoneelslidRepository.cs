﻿using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Crypto.Generators;
using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopData.Repositories
{
    public class PersoneelslidRepository : IPersoneelslidRepository
    {
        private readonly PrulariaComContext _context;
        public PersoneelslidRepository(PrulariaComContext context)
        {
            _context = context;
        }
        public async Task<PersoneelsLid> Create(PersoneelsLid personeelsLid)
        {
            _context.Personeelsledens.Add(personeelsLid);
            _context.SaveChanges();
            return personeelsLid;
        }
        public async Task<PersoneelsLid> FindByEmail(string email)
        {
            return _context.Personeelsledens
                .Include(p => p.PersoneelslidAccount)
                .Where(p => p.PersoneelslidAccount.Emailadres == email)
                .FirstOrDefault();
        }
        public async Task<PersoneelsLid> GetPersoneelslid(int id)
        {
            return _context.Personeelsledens.Include(p => p.PersoneelslidAccount).Where(p => p.PersoneelslidId == id).FirstOrDefault();
        }
        public async Task<PersoneelsLidAccount> GetPersoneelslidAccount(int id) => _context.Personeelslidaccounts.Find(id);
        public async Task ChangePassword(int id, string password)
        {
            PersoneelsLidAccount account = _context.Personeelslidaccounts.Find(id);
            account.Paswoord = password;
            _context.Update(account);
            await _context.SaveChangesAsync();
        }
    }
}
