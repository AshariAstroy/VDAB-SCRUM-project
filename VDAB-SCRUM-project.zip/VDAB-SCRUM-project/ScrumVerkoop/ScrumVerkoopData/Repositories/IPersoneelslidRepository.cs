﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public interface IPersoneelslidRepository
    {
        Task<PersoneelsLid> Create(PersoneelsLid personeelsLid);
        Task<PersoneelsLid> FindByEmail(string email);
        Task<PersoneelsLid> GetPersoneelslid(int id);
        Task<PersoneelsLidAccount> GetPersoneelslidAccount(int id);
        Task ChangePassword(int id, string password);
    }
}
