﻿using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public interface IBestellingRepository
    {
        //Bestelling? GetById(int id);
        Task<Bestelling?> GetByIdAsync(int id);
        List<Bestelling> GetAllBestellingen();
        List<Bestelling> FilterByName(string name);
        
        // Pagination methods
        (List<Bestelling> items, int totalCount) GetBestellingenPaginated(int page, int pageSize);
        (List<Bestelling> items, int totalCount) FilterByNamePaginated(string name, int page, int pageSize);
        (List<Bestelling> items, int totalCount) GetOverdueUnpaidBestellingenPaginated(int page, int pageSize);
        (List<Bestelling> items, int totalCount) GetOverdueUndeliveredBestellingenPaginated(int page, int pageSize);

        void Annuleer(int bestelId);
        bool IsGeannuleerd(int bestelId);
        void UpdateAantalGeannuleerd(int bestellijnId, int aantalGeannuleerd);
        Adres GetAdresById(int id);
        Adres CheckAdres(string straat, string huisnummer, string bus, int plaatsId);
        List<Plaats> GetAllPlaatsen();
        Plaats getPlaatsById(int id);
        void UpdateLeveringsAdres(Bestelling changedBestelling);
        void CreateAdres(string straat, string huisnummer, string bus, int plaatsId);
    }
}