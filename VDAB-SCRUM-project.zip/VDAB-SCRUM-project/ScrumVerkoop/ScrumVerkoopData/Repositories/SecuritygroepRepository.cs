﻿using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopData.Repositories
{
    public class SecuritygroepRepository : ISecuritygroepRepository
    {
        private readonly PrulariaComContext _context;
        public SecuritygroepRepository(PrulariaComContext context)
        {
            _context = context;
        }
        // GetSecuritygroepenVanPersoneelslid
        public async Task<List<Securitygroep>> GetSecuritygroepenVanPersoneelslid(int personeelslidId)
        {
            var securitygroepenVanPersoneelslid =
            from securitygroep in _context.Securitygroepens
            .Include(sg => sg.Personeelslids)
            where securitygroep.Personeelslids.Any(
            p => p.PersoneelslidId == personeelslidId)
            select securitygroep;
            return await securitygroepenVanPersoneelslid.ToListAsync();
            //of
            //return await context.Personeelsleden
            // .Include(p => p.Securitygroepen)
            // .Where(p => p.PersoneelslidId == personeelslidId)
            // .SelectMany(p => p.Securitygroepen).ToListAsync();
        }
    }
}
