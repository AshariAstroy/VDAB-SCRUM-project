﻿using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public interface IKlantRepository
    {
        Task<Klant?> GetByIdAsync(int id);
        List<Klant> GetAllKlanten();

        List<Klant> SearchByNaam(string name);
        List<Klant> FilterByType(bool isBedrijf, List<Klant>? klanten = null);
        List<Klant> FilterByActief(bool actief, List<Klant>? klanten = null);
        List<Klant> FilterByLopendBestellingen(List<Klant>? klanten = null);
        IEnumerable<ContactPersoon> GetContactPersonenByKlantId(int klantId);
        
        // Pagination methods
        (List<Klant> items, int totalCount) GetKlantenPaginated(int page, int pageSize, string search = null, string type = null, string actief = null, bool lopend = false);
        void ChangeContactStatus(int id);
        GebruikerAccount GetGebruikAccount(int id);

        //Get orders in klant detail page
        IEnumerable<Bestelling> GetBestellingenByKlantId(int klantId);
    }

}
