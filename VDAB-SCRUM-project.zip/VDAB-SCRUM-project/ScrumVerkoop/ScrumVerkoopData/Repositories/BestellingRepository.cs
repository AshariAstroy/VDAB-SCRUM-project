﻿using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
	public class BestellingRepository : IBestellingRepository
	{
		private readonly PrulariaComContext _context;
		public BestellingRepository(PrulariaComContext context)
		{
			_context = context;
		}

		public async Task<Bestelling?> GetByIdAsync(int id)
		{
			return await _context.Bestellingens
				.Include(b => b.BestellingsStatus)
				.Include(b => b.Betaalwijze)
				.Include(b => b.FacturatieAdres).ThenInclude(a => a.Plaats)
				.Include(b => b.LeveringsAdres).ThenInclude(a => a.Plaats)
				.Include(b => b.Bestellijnen).ThenInclude(l => l.Artikel)
				.Include(b => b.Klant.Natuurlijkepersonen)
				.Include(b => b.Klant.Rechtspersonen)
				.FirstOrDefaultAsync(b => b.BestelId == id);
		}

		public List<Bestelling> GetAllBestellingen()
		{
			return _context.Bestellingens
				.Include(bestelling => bestelling.BestellingsStatus)
				.Include(bestelling => bestelling.Bestellijnen)
				.Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				.Include(bestelling => bestelling.Klant.Rechtspersonen)
				.OrderByDescending(b => b.Besteldatum).ToList();
		}
		public List<Bestelling> FilterByName(string name)
		{
			if (String.IsNullOrWhiteSpace(name))
			{
				return GetAllBestellingen();
			}
			return _context.Bestellingens
				   .Include(bestelling => bestelling.BestellingsStatus)
				   .Include(bestelling => bestelling.Bestellijnen)
				   .Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				   .Include(bestelling => bestelling.Klant.Rechtspersonen)
				   .Where(bestelling => bestelling.Voornaam.ToLower().Contains(name.ToLower()) || bestelling.Familienaam.ToLower().Contains(name.ToLower()) ||
										(bestelling.Voornaam.ToLower() + " " + bestelling.Familienaam.ToLower()).Contains(name.ToLower()) ||
										(bestelling.Familienaam.ToLower() + " " + bestelling.Voornaam.ToLower()).Contains(name.ToLower()) ||
										(bestelling.Bedrijfsnaam.ToLower().Contains(name.ToLower())))
				   .OrderByDescending(b => b.Besteldatum).ToList();
		}

		public (List<Bestelling> items, int totalCount) GetBestellingenPaginated(int page, int pageSize)
		{
			var query = _context.Bestellingens
				.Include(bestelling => bestelling.BestellingsStatus)
				.Include(bestelling => bestelling.Bestellijnen)
				.Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				.Include(bestelling => bestelling.Klant.Rechtspersonen)
				.OrderByDescending(b => b.Besteldatum);

			var totalCount = query.Count();
			
			var items = pageSize == -1 ? 
				query.ToList() : 
				query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

			return (items, totalCount);
		}

		public (List<Bestelling> items, int totalCount) FilterByNamePaginated(string name, int page, int pageSize)
		{
			if (String.IsNullOrWhiteSpace(name))
			{
				return GetBestellingenPaginated(page, pageSize);
			}

			var query = _context.Bestellingens
				   .Include(bestelling => bestelling.BestellingsStatus)
				   .Include(bestelling => bestelling.Bestellijnen)
				   .Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				   .Include(bestelling => bestelling.Klant.Rechtspersonen)
				   .Where(bestelling => bestelling.Voornaam.ToLower().Contains(name.ToLower()) || bestelling.Familienaam.ToLower().Contains(name.ToLower()) ||
										(bestelling.Voornaam.ToLower() + " " + bestelling.Familienaam.ToLower()).Contains(name.ToLower()) ||
										(bestelling.Familienaam.ToLower() + " " + bestelling.Voornaam.ToLower()).Contains(name.ToLower()) ||
										(bestelling.Bedrijfsnaam != null && bestelling.Bedrijfsnaam.ToLower().Contains(name.ToLower())))
				   .OrderByDescending(b => b.Besteldatum);

			var totalCount = query.Count();
			
			var items = pageSize == -1 ? 
				query.ToList() : 
				query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

			return (items, totalCount);
		}

		public (List<Bestelling> items, int totalCount) GetOverdueUnpaidBestellingenPaginated(int page, int pageSize)
		{
			var cutoffDate = DateTime.Now.AddDays(-6);
			
			var query = _context.Bestellingens
				.Include(bestelling => bestelling.BestellingsStatus)
				.Include(bestelling => bestelling.Bestellijnen)
				.Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				.Include(bestelling => bestelling.Klant.Rechtspersonen)
				.Where(bestelling => !bestelling.Betaald && bestelling.Besteldatum < cutoffDate)
				.OrderByDescending(b => b.Besteldatum);

			var totalCount = query.Count();
			
			var items = pageSize == -1 ? 
				query.ToList() : 
				query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

			return (items, totalCount);
		}

		public (List<Bestelling> items, int totalCount) GetOverdueUndeliveredBestellingenPaginated(int page, int pageSize)
		{
			var cutoffDate = DateTime.Now.AddDays(-6);
			
			var query = _context.Bestellingens
				.Include(bestelling => bestelling.BestellingsStatus)
				.Include(bestelling => bestelling.Bestellijnen)
				.Include(bestelling => bestelling.Klant.Natuurlijkepersonen)
				.Include(bestelling => bestelling.Klant.Rechtspersonen)
				.Where(bestelling => bestelling.BestellingsStatusId != 6 && 
								   bestelling.BestellingsStatusId != 3 && 
								   bestelling.Besteldatum < cutoffDate)
				.OrderByDescending(b => b.Besteldatum);

			var totalCount = query.Count();
			
			var items = pageSize == -1 ? 
				query.ToList() : 
				query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

			return (items, totalCount);
		}

		public bool IsGeannuleerd(int bestelId)
		{
			var bestelling = _context.Bestellingens.Find(bestelId);
			return bestelling.Annulatie;
		}
		// method for change status name to "Geannuleerd"
		private int getBestellingsStatusIdByName(string statusName)
		{
			return _context.Bestellingsstatussens
				.Where(status => status.Naam == statusName)
				.Select(status => status.BestellingsStatusId)
				.FirstOrDefault();
		}
		public void Annuleer(int bestelId)
		{
			var bestelling = _context.Bestellingens.Find(bestelId);
			bestelling.BestellingsStatusId = getBestellingsStatusIdByName("Geannuleerd"); // change name from status to "Geannuleerd"
			bestelling.Annulatie = true;
			bestelling.Annulatiedatum = DateTime.Now;
			_context.Update(bestelling); // update to database name change
			_context.SaveChanges();
		}

        public void UpdateAantalGeannuleerd(int bestellijnId, int aantalGeannuleerd)
        {
            var bestellijn = _context.Bestellijnens.Find(bestellijnId);
            bestellijn.AantalGeannuleerd = aantalGeannuleerd;
            _context.Update(bestellijn);
            _context.SaveChanges();
        }
        public Adres GetAdresById(int id)
        {
            return _context.Adressens.Include(a => a.Plaats).Where(a => a.AdresId == id).FirstOrDefault();
        }
        public int GetPlaatsIdByPostcodeAndNaam(string postcode, string naam)
        {
            return _context.Plaatsens
                .Where(p => p.Postcode == postcode && p.Naam.ToLower() == naam.ToLower())
                .Select(p => p.PlaatsId)
                .FirstOrDefault();
        }
        public Adres CheckAdres(string straat, string huisnummer, string bus, int plaatsId)
        {
            return _context.Adressens
                .Where(a => a.Straat.ToLower() == straat.ToLower() && a.HuisNummer.ToLower() == huisnummer.ToLower() && a.PlaatsId == plaatsId && a.Bus.ToLower() == bus.ToLower())
                .FirstOrDefault();
        }
        public List<Plaats> GetAllPlaatsen()
        {
            return _context.Plaatsens.OrderBy(p => p.Postcode).ToList();
        }
        public async void UpdateLeveringsAdres(Bestelling changedBestelling)
        {
            _context.Update(changedBestelling);
            _context.SaveChanges();
        }
        public void CreateAdres(string straat, string huisnummer, string bus, int plaatsId)
        {
            Adres adres = new Adres
            {
                Straat = straat,
                HuisNummer = huisnummer,
                Bus = bus,
                PlaatsId = plaatsId
            };
            _context.Adressens.Add(adres);
            _context.SaveChanges();
        }
        public Plaats getPlaatsById(int id) => _context.Plaatsens.Find(id);
    }
}
