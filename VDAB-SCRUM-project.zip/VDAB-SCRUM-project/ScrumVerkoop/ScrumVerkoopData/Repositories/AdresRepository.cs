﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public class AdresRepository : IAdresRepository
    {
        private readonly PrulariaComContext _context;
        public AdresRepository(PrulariaComContext context)
        {
            _context = context;
        }

        public Adres GetKlantBestelingAdresById(int id)
        {
            return _context.Adressens.Include(a => a.KlantenLeveringsAdres).Where(a => a.AdresId == id).FirstOrDefault();
        }

        public Adres GetKlantFacturatieAdresById(int id)
        {
            return _context.Adressens.Include(a => a.KlantenFacturatieAdres).Where(a => a.AdresId == id).FirstOrDefault();
        }
        public List<Plaats> GetAllPlaatsen()
        {
            return _context.Plaatsens.OrderBy(p => p.Postcode).ToList();
        }

        public Adres CheckAdres(string straat, string huisNr, string bus, int plaatsId)
        {
            return _context.Adressens
                .FirstOrDefault(a => a.Straat == straat && a.HuisNummer == huisNr && a.Bus == bus && a.PlaatsId == plaatsId);
        }

        public Adres CreateAdres(string straat, string huisNr, string bus, int plaatsId)
        {
            var adres = new Adres
            {
                Straat = straat,
                HuisNummer = huisNr,
                Bus = bus,
                PlaatsId = plaatsId,
                Actief = true
            };

            _context.Adressens.Add(adres);
            _context.SaveChanges();
            return adres;
        }
        public Klant? GetKlantById(int id)
        {
            return _context.Klantens
                .Include(k => k.FacturatieAdres).ThenInclude(a => a.Plaats)
                .Include(k => k.LeveringsAdres).ThenInclude(a => a.Plaats)
                .Include(k => k.Natuurlijkepersonen).ThenInclude(n => n.GebruikersAccount)
                .Include(k => k.Rechtspersonen)
                .FirstOrDefault(k => k.KlantId == id);
        }

        public void UpdateAdres(Klant klant)
        {
            _context.Klantens.Update(klant);
            _context.SaveChanges();
        }
    }
}
