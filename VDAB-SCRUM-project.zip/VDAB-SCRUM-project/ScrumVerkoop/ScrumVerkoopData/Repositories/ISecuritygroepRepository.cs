﻿using ScrumVerkoopData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopData.Repositories
{
    public interface ISecuritygroepRepository
    {
        Task<List<Securitygroep>> GetSecuritygroepenVanPersoneelslid(int personeelslidId);
    }
}
