﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScrumVerkoopData.Models;

namespace ScrumVerkoopData.Repositories
{
    public interface IAdresRepository
    {
        Klant GetKlantById(int klantId);
        Adres GetKlantFacturatieAdresById(int id);
        Adres GetKlantBestelingAdresById(int id);
        List<Plaats> GetAllPlaatsen();
        public void UpdateAdres(Klant klant);

        public Adres CheckAdres(string straat, string huisNr, string bus, int plaatsId);
        public Adres CreateAdres(string straat, string huisNr, string bus, int plaatsId);
    }
}
