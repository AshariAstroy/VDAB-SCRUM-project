﻿using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace ScrumVerkoopService
{
    public class BestellingService
    {
        private IBestellingRepository repository;
        public BestellingService(IBestellingRepository repository)
        {
            this.repository = repository;
        }
        public List<Bestelling> GetAllBestellingen() => repository.GetAllBestellingen();
        public List<Bestelling> FilterByName(string name) => repository.FilterByName(name);
        
        // Pagination methods
        public (List<Bestelling> items, int totalCount) GetBestellingenPaginated(int page, int pageSize) 
            => repository.GetBestellingenPaginated(page, pageSize);
        public (List<Bestelling> items, int totalCount) FilterByNamePaginated(string name, int page, int pageSize) 
            => repository.FilterByNamePaginated(name, page, pageSize);
        public (List<Bestelling> items, int totalCount) GetOverdueUnpaidBestellingenPaginated(int page, int pageSize) 
            => repository.GetOverdueUnpaidBestellingenPaginated(page, pageSize);
        public (List<Bestelling> items, int totalCount) GetOverdueUndeliveredBestellingenPaginated(int page, int pageSize) 
            => repository.GetOverdueUndeliveredBestellingenPaginated(page, pageSize);
            
        public void BestellingCancel(int bestelId)
        {
            //using var scope = new TransactionScope();
            if (!repository.IsGeannuleerd(bestelId))
                repository.Annuleer(bestelId);
            //scope.Complete();
        }
        public async Task<Bestelling?> GetByIdAsync(int id)
        {
            return await repository.GetByIdAsync(id);
        }

        public void UpdateAantalGeannuleerd(int bestellijnId, int aantalGeannuleerd)
        {
            repository.UpdateAantalGeannuleerd(bestellijnId, aantalGeannuleerd);
        }
        public List<Plaats> GetAllPlaatsen() => repository.GetAllPlaatsen();
        public Adres CheckAdres(string straat, string huisnummer, string bus, int plaatsId) => repository.CheckAdres(straat, huisnummer, bus, plaatsId);
        public Adres GetBestellingAdres(int id) => repository.GetAdresById(id);
        public void UpdateLeveringsAdres(Bestelling bestelling) => repository.UpdateLeveringsAdres(bestelling);
        public void CreateAdres(string straat, string huisnummer, string bus, int plaatsId) => repository.CreateAdres(straat, huisnummer, bus, plaatsId);
        public Plaats getPlaatsById(int id) => repository.getPlaatsById(id);
    }
}
