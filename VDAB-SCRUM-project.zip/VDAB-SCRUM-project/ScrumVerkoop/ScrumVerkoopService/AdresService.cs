﻿using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopService
{
    public class AdresService
    {
        private readonly IAdresRepository repository;

        public AdresService(IAdresRepository repository)
        {
            this.repository = repository;
        }
        public Klant GetKlantById(int klantId) => repository.GetKlantById(klantId);
        public void UpdateAdres(Klant klant) => repository.UpdateAdres(klant);
        public Adres GetKlantFacturatieAdresById(int adresId) => repository.GetKlantFacturatieAdresById(adresId);
        public Adres GetKlantBestelingAdresById(int adresId) => repository.GetKlantBestelingAdresById(adresId);
        public List<Plaats> GetAllPlaatsen() => repository.GetAllPlaatsen();

        public Adres CheckAdres(string straat, string huisNr, string bus, int plaatsId) => repository.CheckAdres(straat, huisNr, bus, plaatsId);
        public void CreateAdres(string straat, string huisNr, string bus, int plaatsId) => repository.CreateAdres(straat, huisNr, bus, plaatsId);
    }
}