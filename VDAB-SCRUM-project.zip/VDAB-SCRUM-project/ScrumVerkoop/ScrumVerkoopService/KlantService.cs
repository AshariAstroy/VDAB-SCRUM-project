﻿using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopService
{
    public class KlantService
    {
        private readonly IKlantRepository repository;
        public KlantService(IKlantRepository repository)
        {
            this.repository = repository;
        }
        public IEnumerable<ContactPersoon> GetContactPersonenByKlantId(int id) => repository.GetContactPersonenByKlantId(id);
        public List<Klant> GetAllKlanten() => repository.GetAllKlanten();
        public List<Klant> GetKlantenByName(string name) => repository.SearchByNaam(name);
        public IEnumerable<Bestelling> GetBestellingenByKlantId(int klantId) => repository.GetBestellingenByKlantId(klantId);
        public (List<Klant> items, int totalCount) GetKlantenPaginated(int page, int pageSize, string search = null, string type = null, string actief = null, bool lopend = false)
            => repository.GetKlantenPaginated(page, pageSize, search, type, actief, lopend);
        // Search filters
        public List<Klant> SearchByNaam(string name) => repository.SearchByNaam(name);
        public List<Klant> FilterByType(bool isBedrijf, List<Klant>? klanten = null) => repository.FilterByType(isBedrijf);
        public List<Klant> FilterByActief(bool actief, List<Klant>? klanten = null) => repository.FilterByActief(actief);
        public List<Klant> FilterByLopendBestellingen(List<Klant>? klanten = null) => repository.FilterByLopendBestellingen();
        public void ChangeContactStatus(int id) => repository.ChangeContactStatus(id);
        public GebruikerAccount GetGebruikAccount(int id) => repository.GetGebruikAccount(id);
    }
}
