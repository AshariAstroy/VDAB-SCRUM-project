﻿using Org.BouncyCastle.Crypto.Generators;
using ScrumVerkoopData.Models;
using ScrumVerkoopData.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ScrumVerkoopService
{
    public class AccountService
    {
        private readonly IPersoneelslidRepository personeelslidRepository;
        private readonly ISecuritygroepRepository securitygroepRepository;
        public AccountService(IPersoneelslidRepository personeelslidRepository, ISecuritygroepRepository securitygroepRepository)
        {
            this.personeelslidRepository = personeelslidRepository;
            this.securitygroepRepository = securitygroepRepository;
        }
        public async Task<PersoneelsLid> Registreer(PersoneelsLid model)
        {
            var personeelslidMetHetzelfdeEmailAdres =
                await personeelslidRepository.FindByEmail(model.PersoneelslidAccount.Emailadres);
            if (personeelslidMetHetzelfdeEmailAdres != null)
                throw new ArgumentException("E-mailadres bestaat al");
            var nieuwPersoneelslid = new PersoneelsLid
            {
                Familienaam = model.Familienaam,
                Voornaam = model.Voornaam,
                InDienst = model.InDienst,
                PersoneelslidAccount = new PersoneelsLidAccount()
            };
            nieuwPersoneelslid.PersoneelslidAccount.Emailadres = model.PersoneelslidAccount.Emailadres;
            nieuwPersoneelslid.PersoneelslidAccount.Paswoord = EncrypteerPaswoord(model.PersoneelslidAccount.Paswoord);
            return await personeelslidRepository.Create(nieuwPersoneelslid);
        }
        private static string EncrypteerPaswoord(string paswoord)
        {
            return BCrypt.Net.BCrypt.HashPassword(paswoord);
        }
        public async Task<PersoneelsLid?> Login(string email, string paswoord)
        {
            var personeelslid = await personeelslidRepository.FindByEmail(email);
            if (personeelslid == null ||
            !VerifyPaswoord(paswoord, personeelslid.PersoneelslidAccount.Paswoord))
            {
                return null;
            }
            return personeelslid;
        }

        public bool VerifyPaswoord(string paswoord, string paswoordHash)
        {
            {
                return BCrypt.Net.BCrypt.Verify(paswoord, paswoordHash);
            }
        }
        // GetSecuritygroepenVanPersoneelslid
        public async Task<List<Securitygroep>> GetSecuritygroepenVanPersoneelslid(int personeelslidId) =>
            await securitygroepRepository.GetSecuritygroepenVanPersoneelslid(personeelslidId);
        public async Task<PersoneelsLid> GetPersoneelslid(int id) => await personeelslidRepository.GetPersoneelslid(id);
        public async Task<PersoneelsLidAccount> GetPersoneelslidAccount(int id) => await personeelslidRepository.GetPersoneelslidAccount(id);
        public async Task ChangePassword(int id, string newPassword) => await personeelslidRepository.ChangePassword(id, EncrypteerPaswoord(newPassword));
    }
}
